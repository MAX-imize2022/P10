﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ButterflyStep3")]
    public class ButterflyStep3 : Activity//, Android.Views.View.IOnClickListener
    {
        Button btnnext3;
        LinearLayout btr3layout;



        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ButterFlyStep3);
            InitViews();

            // Create your application here
        }

        private void InitViews()
        {
            btr3layout = FindViewById<LinearLayout>(Resource.Id.btr3layout);
            btr3layout.Click += btr3layout_Click;
        }

        private void btr3layout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(ButterflyLastActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
        //public void OnClick(View v)
        //{
        //    if (v == btnnext3)
        //    {
        //        Intent intent = new Intent(this, typeof(ButterflyLastActivity));
        //        StartActivity(intent);
        //    }

        //}
    }
}