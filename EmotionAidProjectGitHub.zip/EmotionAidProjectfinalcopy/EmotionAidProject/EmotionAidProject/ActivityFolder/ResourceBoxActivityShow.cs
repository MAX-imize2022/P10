﻿using Android;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using EmotionAidProject.Listeners;
using EmotionAidProject.Model;
using EmotionAidProject.Service_BroadCast;
using Firebase.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ResourceBoxActivityShow")]
    public class ResourceBoxActivityShow : Activity
    {
        ResourceEventListener resourceEventListener;
        Spinner addResourceSpinner;
        readonly string[] permissionGroup =
        {
            Manifest.Permission.ReadExternalStorage,
            Manifest.Permission.WriteExternalStorage,
            Manifest.Permission.Camera
        };
        ImageView addResourceImageView;
        public byte[] FileBytes { get; set; }
        string categoryName, resourceName, resourceText;
        ResourceBoxClass resource;
        StorageReference storageReference;
        public const string RESOURCE_IMAGE = "resourcesImages/";
        ProgressDialog progressDialog;
        ResourceAdapter resourceAdapter;
        List<ResourceBoxClass> resourcesList;
        ListView addResourceListView;
        List<ResourceBoxClass> resourcesListFilterByCategory;
        DownloadReciver downloadReceiver;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ResourceBoxLayoutShow);
            InitViews();

            // Create your application here
        }

        private void InitViews()
        {
            this.addResourceListView = (ListView)this.FindViewById(Resource.Id.addResourceListView);
            this.addResourceImageView = (ImageView)this.FindViewById(Resource.Id.addResourceImageView);
            //this.addResourceImageView.Click += AddResourceImageView_Click;
            this.RequestPermissions(permissionGroup, 0);
            this.resourceEventListener = new ResourceEventListener();
            this.resourceEventListener.OnResourcesRetrieved += ResourceEventListener_OnResourcesRetrieved;
            this.addResourceListView.ItemLongClick += AddResourceListView_ItemLongClick;
            this.downloadReceiver = new DownloadReciver(this.addResourceImageView, this);
        }

        private void AddResourceListView_ItemLongClick(object sender, AdapterView.ItemLongClickEventArgs e)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.SetTitle("Do you want to delete this resource from the list?");
            builder.SetCancelable(true);
            builder.SetPositiveButton("Delete", (s, args) =>
            {
                ResourceBoxClass resource = this.resourcesListFilterByCategory[e.Position];
                resource.Delete();
            });
            builder.SetNegativeButton("Dismiss", Dialog_Dismiss_Click);
            builder.Show();
        }

        private void Dialog_Dismiss_Click(object sender, DialogClickEventArgs e)
        {
            Toast.MakeText(this, "Item did not removed", ToastLength.Short).Show();
        }

        private void ResourceEventListener_OnResourcesRetrieved(object sender, ResourceEventListener.ResourceEventArgs e)
        {
            this.resourcesList = e.Resources;
            //Toast.MakeText(this, " שינוי באוסףמוצרים בענן", ToastLength.Long).Show();
            if (this.resourcesList == null)
            {
                this.resourcesListFilterByCategory = new List<ResourceBoxClass>();
            }
            else
            {
                //this.resourcesListFilterByCategory = this.resourcesList.Where(p => p.CategoryName == this.categoryName).ToList();
                this.resourcesListFilterByCategory = this.resourcesList.ToList();

            }
            this.resourceAdapter = new ResourceAdapter(this, this.resourcesListFilterByCategory);
            this.addResourceListView.Adapter = this.resourceAdapter;
        }

      
    }
}