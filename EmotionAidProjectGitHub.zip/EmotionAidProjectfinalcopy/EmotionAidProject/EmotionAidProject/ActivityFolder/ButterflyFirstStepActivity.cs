﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ButterflyFirstStepActivity")]
    public class ButterflyFirstStepActivity : Activity//, Android.Views.View.IOnClickListener
    {
        Button btnnext1;
        LinearLayout BtrFirstLayout;


        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ButterflyStep1);
            InitViews();
            

            // Create your application here
        }
        private void InitViews()
        {
            BtrFirstLayout = FindViewById<LinearLayout>(Resource.Id.BtrFirstLayout);
            BtrFirstLayout.Click += BtrFirstLayout_Click;
        }

        private void BtrFirstLayout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(ButterflyStep2Activity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
        //public void OnClick(View v)
        //{
        //    if (v == btnnext1)
        //    {
        //        Intent intent = new Intent(this, typeof(ButterflyStep2Activity));
        //        StartActivity(intent);
        //    }

        //}
    }
}