﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "Grounding4thActivity")]
    public class Grounding4thActivity : Activity
    {
        LinearLayout grounding4thlayout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Grounding4thLayout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            grounding4thlayout = FindViewById<LinearLayout>(Resource.Id.grounding4thlayout);
            grounding4thlayout.Click += grounding4thlayout_Click;
        }

        private void grounding4thlayout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(Grounding5thAcivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}