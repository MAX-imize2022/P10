﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ButterflyStep2Activity")]
    public class ButterflyStep2Activity : Activity//, Android.Views.View.IOnClickListener
    {
        Button btnnext2;
        LinearLayout btrSecondLayout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ButterflyStep2);
            // Create your application here
            InitViews();
        }
        private void InitViews()
        {
            btrSecondLayout = FindViewById<LinearLayout>(Resource.Id.btrSecondLayout);
            btrSecondLayout.Click += btrSecondLayout_Click;


        }

        private void btrSecondLayout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(ButterflyStep3));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
        //public void OnClick(View v)
        //{
        //    if (v == btnnext2)
        //    {
        //        Intent intent = new Intent(this, typeof(ButterflyStep3));
        //        StartActivity(intent);
        //    }

        //}


    }
}