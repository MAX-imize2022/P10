﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "DischargeStep4DropBoxActivity")]
    public class DischargeStep4DropBoxActivity : Activity
    {
        Spinner spinner;
        Button btnnextstep;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.DischargeStep4DropBox);
            Spinner spinner = FindViewById<Spinner>(Resource.Id.spinner);
            var adapter = ArrayAdapter.CreateFromResource(
            this, Resource.Array.planets_array, Android.Resource.Layout.SimpleSpinnerItem);
            adapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            spinner.Adapter = adapter;

            btnnextstep = FindViewById<Button>(Resource.Id.btnnextstep);
            btnnextstep.Click += btnnextstep_Click;


            // Create your application here
            //InitViews();
        }

        private void btnnextstep_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(LastScale));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }

        private void InitViews()
        {
            
        }
    }
}