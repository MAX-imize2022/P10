﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "SelfSooth3rdActivity")]
    public class SelfSooth3rdActivity : Activity
    {
        LinearLayout self3rdlayout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.SelfSoothing3rdLayout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            self3rdlayout = FindViewById<LinearLayout>(Resource.Id.self3rdlayout);
            self3rdlayout.Click += self3rdlayout_Click;
        }

        private void self3rdlayout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(SelfSoothLastActivity));
            StartActivity(intent);
        }
    }
}