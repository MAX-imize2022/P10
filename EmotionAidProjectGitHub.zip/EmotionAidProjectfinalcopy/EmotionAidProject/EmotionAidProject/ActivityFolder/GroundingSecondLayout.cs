﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "GroundingSecondLayout")]
    public class GroundingSecondLayout : Activity
    {
        LinearLayout groundingsecondlayout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.GroundingSecondLayout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            groundingsecondlayout = FindViewById<LinearLayout>(Resource.Id.groundingsecondlayout);
            groundingsecondlayout.Click += groundingsecondlayout_Click;
        }

        private void groundingsecondlayout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(Grounding3rdAcitvity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}