﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "Discharge3rdActivity")]
    public class Discharge3rdActivity : Activity
    {
        LinearLayout discharge3Layout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Discharge3rdLayout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            discharge3Layout = FindViewById<LinearLayout>(Resource.Id.discharge3Layout);
            discharge3Layout.Click += discharge3Layout_Click;
        }

        private void discharge3Layout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(Discharge4rdActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}