﻿using Android;
using Android.App;
using Android.Content;
using Android.Gms.Extensions;
using Android.Graphics;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using EmotionAidProject.Listeners;
using EmotionAidProject.Model;
using EmotionAidProject.Service_BroadCast;
using Firebase.Storage;
using Plugin.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ResourcesBoxActivity")]
    public class ResourcesBoxActivity : Activity
    {
        ResourceEventListener resourceEventListener;
        Spinner addResourceSpinner;
        readonly string[] permissionGroup =
        {
            Manifest.Permission.ReadExternalStorage,
            Manifest.Permission.WriteExternalStorage,
            Manifest.Permission.Camera
        };
        ImageView addResourceImageView;
        EditText addResourceEditText;
        EditText addCategory;
        EditText addResourceName;
        Button addResourceButton;
        public byte[] FileBytes { get; set; }
        string categoryName ,resourceName,resourceText ;
        ResourceBoxClass resource;
        StorageReference storageReference;
        public const string RESOURCE_IMAGE = "resourcesImages/";
        ProgressDialog progressDialog;
        ResourceAdapter resourceAdapter;
        List<ResourceBoxClass> resourcesList;
        ListView addResourceListView;
        List<ResourceBoxClass> resourcesListFilterByCategory;
        DownloadReciver downloadReceiver;
        
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            this.SetContentView(Resource.Layout.layoutAddResource);
            this.Initalize();

            // Create your application here
        }

        private void Initalize()
        {
            
            this.addResourceListView = (ListView)this.FindViewById(Resource.Id.addResourceListView);
            this.addResourceButton = (Button)this.FindViewById(Resource.Id.addResourceButton);
            this.addResourceButton.Click += AddResourceButton_Click;
            this.addResourceEditText = (EditText)this.FindViewById(Resource.Id.addResourceEditText);
            this.addCategory = (EditText)this.FindViewById(Resource.Id.addCategory);
            this.addResourceName = (EditText)this.FindViewById(Resource.Id.addResourceName);
            this.addResourceImageView = (ImageView)this.FindViewById(Resource.Id.addResourceImageView);
            this.addResourceImageView.Click += AddResourceImageView_Click;
            this.RequestPermissions(permissionGroup, 0);
            //this.addResourceSpinner = (Spinner)this.FindViewById(Resource.Id.addResourceSpinner);
            //this.addResourceSpinner.ItemSelected += AddResourceSpinner_ItemSelected;
            this.resourceEventListener = new ResourceEventListener();
            this.resourceEventListener.OnResourcesRetrieved += ResourceEventListener_OnResourcesRetrieved;
            this.addResourceListView.ItemLongClick += AddResourceListView_ItemLongClick;
            this.downloadReceiver = new DownloadReciver(this.addResourceImageView, this);
        }

        

        private async void AddResourceButton_Click(object sender, EventArgs e)
        {
            categoryName = addCategory.Text;
            Toast.MakeText(this, categoryName, ToastLength.Short).Show();
            if (this.categoryName == "")
            {
                Toast.MakeText(this, "עליך לבחור סוגה", ToastLength.Long).Show();
                return;
            }
            if (this.addResourceEditText.Text == "")
            {
                Toast.MakeText(this, "עליך לבחור שם למשאב", ToastLength.Long).Show();
                return;
            }
            Toast.MakeText(this, addResourceEditText.Text, ToastLength.Short).Show();

            this.ShowProgressDialogue("......הוספת מוצר");
            string resourceName = this.addResourceEditText.Text;
            Toast.MakeText(this, resourceName, ToastLength.Short).Show();
            //("aaa", "bbb", "ccc");
            //(resourceName, categoryName, addResourceEditText.Text);
            this.resource = new ResourceBoxClass(resourceName,categoryName,this.addResourceEditText.Text);
            if (await this.resource.Exist())
            {
                Toast.MakeText(this, "המוצר כבר קיים", ToastLength.Short).Show();
                //this.CloseProgressDialogue();
                return;
            }
            this.storageReference = FirebaseStorage.Instance.GetReference(RESOURCE_IMAGE + this.resource.ResourceId);
            await this.storageReference.PutBytes(this.FileBytes);
            string resourceImageUrl = "";
            if (this.storageReference != null)
            {
                resourceImageUrl = (await this.storageReference.DownloadUrl).ToString();
                Toast.MakeText(this, resourceImageUrl, ToastLength.Long).Show();
            }
            this.resource.ImageUrl = resourceImageUrl;
            if (await resource.AddResource() == true)
            {
                Toast.MakeText(this, "המוצר התווסף", ToastLength.Long).Show();
            }
            else
            {
                Toast.MakeText(this, "המוצר  לא התווסף", ToastLength.Long).Show();
            }
            this.progressDialog.Dismiss();
        }

     

      

        private void AddResourceImageView_Click(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder builder = new Android.Support.V7.App.AlertDialog.Builder(this);
            builder.SetMessage("הוספת תמונת מוצר");
            builder.SetNegativeButton("צילום תמונה", (senderObj, args) =>
            {
                this.TakePhoto();
            });
            builder.SetPositiveButton("בחירת תמונה", SelectPhoto);
            //builder.SetNeutralButton("בחירת תמונה מהרשת", SelectIntertPhoto);
            builder.Show();
        }

        //private void SelectIntertPhoto(object sender, DialogClickEventArgs e)
        //{
        //    Dialog dialog = new Dialog(this);
        //    dialog.SetContentView(Resource.Layout.layoutDialogDownloadImage);
        //    dialog.SetTitle("הורדת תמונת מהמירשתת");
        //    dialog.SetCancelable(true); 
        //     EditText etUrl = dialog.FindViewById<EditText>(Resource.Id.DialogDownload_et);
        //    Button btnDownload = dialog.FindViewById<Button>(Resource.Id.DialogDownloaded_Btn);
        //    btnDownload.Click += async (o, args) =>
        //    {
        //        if (etUrl.Text != "")
        //        {
        //            Intent intent = new Intent(this, typeof(DownLoadService));
        //            intent.PutExtra("strUrl", etUrl.Text);
        //            this.StartService(intent);
        //            dialog.Dismiss();
        //        }
        //    };

        //    dialog.Show();
        //}

        private async void SelectPhoto(object sender, DialogClickEventArgs e)
        {
            await CrossMedia.Current.Initialize();
            if (!CrossMedia.Current.IsPickPhotoSupported)
            {
                Toast.MakeText(this, "Upload not supported", ToastLength.Short).Show();
                return;
            }
            var file = await CrossMedia.Current.PickPhotoAsync(new Plugin.Media.Abstractions.PickMediaOptions
            {
                PhotoSize = Plugin.Media.Abstractions.PhotoSize.Medium,
                CompressionQuality = 20,
            });
            if (file == null)
            {
                return;
            }
            this.FileBytes = System.IO.File.ReadAllBytes(file.Path);

            Bitmap bitmap = BitmapFactory.DecodeByteArray(FileBytes, 0, FileBytes.Length);
            this.addResourceImageView.SetImageBitmap(bitmap);
        }

        private async void TakePhoto()
        {
            await CrossMedia.Current.Initialize();
            var file = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions
            {
                PhotoSize = Plugin.Media.Abstractions.PhotoSize.Medium,
                CompressionQuality = 20,
                Directory = "categories",
                Name = "c1234.jpg"
            });
            if (file == null)
            {
                return;
            }
            //Converts file.path to byte array and set the resulting bitmap to imageview
            this.FileBytes = System.IO.File.ReadAllBytes(file.Path);
            Bitmap bitmap = BitmapFactory.DecodeByteArray(FileBytes, 0, FileBytes.Length);
            this.addResourceImageView.SetImageBitmap(bitmap);
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            this.UnregisterReceiver(downloadReceiver);
        }
        protected override void OnResume()
        {
            base.OnResume();

            this.RegisterReceiver(downloadReceiver, new IntentFilter("radio.GAGA.Leroy.MasterYehudai"));
        }


        private void AddResourceListView_ItemLongClick(object sender, AdapterView.ItemLongClickEventArgs e)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.SetTitle("Do you want to delete this resource from the list?");
            builder.SetCancelable(true);
            builder.SetPositiveButton("Delete", (s, args) =>
            {
                ResourceBoxClass resource = this.resourcesListFilterByCategory[e.Position];
                resource.Delete();
            });
            builder.SetNegativeButton("Dismiss", Dialog_Dismiss_Click);
            builder.Show();
        }

        private void Dialog_Dismiss_Click(object sender, DialogClickEventArgs e)
        {
            Toast.MakeText(this, "Item did not removed", ToastLength.Short).Show();
        }

        private void ResourceEventListener_OnResourcesRetrieved(object sender, ResourceEventListener.ResourceEventArgs e)
        {
            this.resourcesList = e.Resources;
            //Toast.MakeText(this, " שינוי באוסףמוצרים בענן", ToastLength.Long).Show();
            if (this.resourcesList == null)
            {
                this.resourcesListFilterByCategory = new List<ResourceBoxClass>();
            }
            else
            {
                //this.resourcesListFilterByCategory = this.resourcesList.Where(p => p.CategoryName == this.categoryName).ToList();
                this.resourcesListFilterByCategory = this.resourcesList.ToList();

            }
            this.resourceAdapter = new ResourceAdapter(this, this.resourcesListFilterByCategory);
            this.addResourceListView.Adapter = this.resourceAdapter;
        }

        //private void AddProductSpinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        //{
        //    this.categoryName = this.categoriesList[e.Position].CategoryName;
        //    //Toast.MakeText(this, this.categoryName, ToastLength.Short).Show();
        //    if (this.productsList == null)
        //    {
        //        this.productsListFilterByCategory = new List<Product>();
        //    }
        //    else
        //    {
        //        this.productsListFilterByCategory = this.productsList.Where(p => p.CategoryName == this.categoryName).ToList();
        //    }
        //    this.productAdapter = new ProductAdapter(this, this.productsListFilterByCategory);
        //    this.addProductListView.Adapter = this.productAdapter;
        //}
        void ShowProgressDialogue(string status)
        {
            this.progressDialog = new ProgressDialog(this);
            progressDialog.SetCancelable(false);
            progressDialog.SetMessage(status);
            progressDialog.SetProgressStyle(ProgressDialogStyle.Spinner);
            progressDialog.Show();
        }
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Android.Content.PM.Permission[] grantResults)
        {
            Plugin.Permissions.PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

    }
}