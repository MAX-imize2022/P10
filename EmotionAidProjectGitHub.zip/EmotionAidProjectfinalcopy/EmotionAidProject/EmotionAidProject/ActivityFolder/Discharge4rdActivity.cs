﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "Discharge4rdActivity")]
    public class Discharge4rdActivity : Activity
    {
        LinearLayout discharge4Layout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Discharge4thLayout);
            InitViews();

            // Create your application here
        }

        private void InitViews()
        {
            discharge4Layout = FindViewById<LinearLayout>(Resource.Id.discharge4Layout);
            discharge4Layout.Click += discharge4Layout_Click;
        }

        private void discharge4Layout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(DischargeStep4DropBoxActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }

    }
}