﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "FirstScale")]
    public class LastScale : Activity, Android.Views.View.IOnClickListener, SeekBar.IOnSeekBarChangeListener
    {
        Button btnFirst;
        SeekBar sb1;
        ImageView iv1;
        int pressure;
        LinearLayout lastscale;
        int[] bmp = new int[5] { Resource.Drawable.SmileChar, Resource.Drawable.charthree, Resource.Drawable.charfive, Resource.Drawable.charseven, Resource.Drawable.charnine };

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.LastScaleLayout);
            InitViews();
            // Create your application here
        }
        //  public class MidScale : Activity,SeekBar.IOnSeekBarChangeListener

        private void InitViews()
        {
            btnFirst = FindViewById<Button>(Resource.Id.btnFirst);
            //btnFirst.SetOnClickListener(this);
            sb1 = FindViewById<SeekBar>(Resource.Id.sb1);
            sb1.SetOnSeekBarChangeListener(this);
            iv1 = FindViewById<ImageView>(Resource.Id.iv1);
            //lastscale = FindViewById<LinearLayout>(Resource.Id.lastscale);
            btnFirst.Click += btnFirst_Click;

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {

            Intent intent = new Intent(this, typeof(ResourceBoxActivityShow));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);


        }

        public void OnClick(View v)
        {
            //
        }

        public void OnProgressChanged(SeekBar seekBar, int progress, bool fromUser)
        {
            pressure = progress / 10;

        }

        public void OnStartTrackingTouch(SeekBar seekBar)
        {
            Toast.MakeText(this, "start = ", ToastLength.Short).Show();

        }

        public void OnStopTrackingTouch(SeekBar seekBar)
        {
            Toast.MakeText(this, "stopped =  " + pressure, ToastLength.Short).Show();

            if (pressure > 0 && pressure <= 20)
            {
                iv1.SetBackgroundResource(bmp[0]);
            }
            if (pressure > 2 && pressure <= 40)
            {
                iv1.SetBackgroundResource(bmp[1]);
            }
            if (pressure < 4 && pressure <= 60)
            {
                iv1.SetBackgroundResource(bmp[2]);
            }
            if (pressure > 6 && pressure <= 80)
            {
                iv1.SetBackgroundResource(bmp[3]);
            }
            if (pressure > 8 && pressure <= 100)
            {
                iv1.SetBackgroundResource(bmp[4]);
            }
            //switch (pressure)
            //{
            //    case <=2:
            //        iv1.SetBackgroundResource(bmp[0]);
            //        break;
            //    case (4):
            //        break;
            //    case (6):
            //        iv1.SetBackgroundResource(bmp[2]);
            //        break;
            //    case 8:
            //        iv1.SetBackgroundResource(bmp[3]);
            //        break;
            //    case 10:
            //        iv1.SetBackgroundResource(bmp[4]);
            //        break;

            //    default:
            //        iv1.SetBackgroundResource(bmp[0]);
            //        break;

            //}


        }







    }
}