﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ResourceStep2Activity")]
    public class ResourceStep2Activity : Activity
    {
        LinearLayout resourcestep2;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ResourceStep2Layout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {

            resourcestep2 = FindViewById<LinearLayout>(Resource.Id.resourcestep2);
            resourcestep2.Click += resourcestep2_Click;
        }

        private void resourcestep2_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(ResourceBoxActivityShow));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}