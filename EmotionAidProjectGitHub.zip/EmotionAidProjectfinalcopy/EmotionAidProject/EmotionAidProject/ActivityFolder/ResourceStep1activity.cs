﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ResourceStep1activity")]
    public class ResourceStep1activity : Activity
    {
        LinearLayout resourcestep1;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ResourcesStep1Layout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {

            resourcestep1 = FindViewById<LinearLayout>(Resource.Id.resourcestep1);
            resourcestep1.Click += resourcestep1_Click;
        }

        private void resourcestep1_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(ResourceStep2Activity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}