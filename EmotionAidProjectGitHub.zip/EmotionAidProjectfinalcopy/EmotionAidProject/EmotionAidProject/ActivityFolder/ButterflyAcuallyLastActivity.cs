﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ButterflyAcuallyLastActivity")]
    public class ButterflyAcuallyLastActivity : Activity,Android.Views.View.IOnClickListener
    {
        Button btnnextstep;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ButterflyActuallyLast);
           InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            btnnextstep = FindViewById<Button>(Resource.Id.btnnextstep);
            btnnextstep.SetOnClickListener(this);
        }
        public void OnClick(View v)
        {
            if (v == btnnextstep)
            {
                Intent intent = new Intent(this, typeof(GroundingFirstActivity));
                StartActivity(intent);
                OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);
            }

        }
    }
}