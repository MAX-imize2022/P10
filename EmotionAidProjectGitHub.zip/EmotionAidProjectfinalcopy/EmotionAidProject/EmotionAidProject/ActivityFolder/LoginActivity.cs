﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;
using EmotionAidProject.Model;
using System;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "LoginActivity")]
    public class LoginActivity : Activity
    {
        EditText etEmail;
        EditText etPassword;
        TextView etSignUp;
        Button btnsavelogin;
        //ProgressDialog progressDialog;
        UserData user;
        string email, password;

        //public void OnClick(View v)
        //{
        //    if (v == btnsave)
        //    {
        //        Intent intent = new Intent(this, typeof(FirstScale));
        //        StartActivity(intent);
        //    }
        //}

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.LoginLayout);



            // Create your application here
            //btnsave = FindViewById<Button>(Resource.Id.btnsavelogin);
            //btnsave.SetOnClickListener(this);
            InitViews();
        }
        private void InitViews()
        {

            etEmail = FindViewById<EditText>(Resource.Id.etEmailLogin);
            //etEmail.getBackground().clearColorFilter();
            etEmail.Background.ClearColorFilter();
            etPassword = FindViewById<EditText>(Resource.Id.etPasswordLogin);
            etPassword.Background.ClearColorFilter();
            etSignUp = FindViewById<TextView>(Resource.Id.etSignUp);
            etSignUp.Click += EtSignUp_Click;

            btnsavelogin = (Button)this.FindViewById(Resource.Id.btnsavelogin);
            //btnsavelogin.Click += ButtonLoginEmailPassword_Click;
            btnsavelogin.Click += Btnsavelogin_Click;
            //progressDialog = new ProgressDialog(this);
            



        }

        private void EtSignUp_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(Register));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);
        }


        private async void Btnsavelogin_Click(object sender, EventArgs e)
        {

            email = this.etEmail.Text;
            password = this.etPassword.Text;
            
            if (email == "")
            {
                Toast.MakeText(this, "you should enter an Email", ToastLength.Short).Show();
                return;
            }
            
            if (password == "")
            {
                Toast.MakeText(this, "you should enter a password", ToastLength.Short).Show();
                return;
            }

            // this.ShowProgressDialogue("loggin.......");
            this.user = new UserData(email, password);

            if (await this.user.Login() == true)
            {
                Toast.MakeText(this, email + "," + password, ToastLength.Short).Show();
                // this.progressDialog.Dismiss();
                Intent intent = new Intent(this, typeof(FirstScale));
                StartActivity(intent);
                this.Finish();
            }
            else
            {
                Toast.MakeText(this, "login- not succssed", ToastLength.Short).Show();
            }
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }




        //void ShowProgressDialogue(string status)
        //{
        //    this.progressDialog = new ProgressDialog(this);
        //    progressDialog.SetCancelable(false);
        //    progressDialog.SetMessage(status);
        //    progressDialog.SetProgressStyle(ProgressDialogStyle.Spinner);
        //    progressDialog.Show();
        //}
    }
}

