﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "ButterflyLastActivity")]
    public class ButterflyLastActivity : Activity
    {
        Button btnnext4;
        LinearLayout btr4thlayout;


        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ButterFlyLast);
            Initviews();
            // Create your application here
        }

        private void Initviews()
        {
            btr4thlayout = FindViewById<LinearLayout>(Resource.Id.btr4thlayout);
            btr4thlayout.Click += btr3layout_Click;
        }

        private void btr3layout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(ButterflyAcuallyLastActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}