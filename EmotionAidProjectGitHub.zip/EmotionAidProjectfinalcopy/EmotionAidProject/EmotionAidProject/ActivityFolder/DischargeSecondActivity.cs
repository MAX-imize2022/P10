﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "DischargeSecondActivity")]
    public class DischargeSecondActivity : Activity
    {
        LinearLayout Discharge2Layout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.DischargeSecondLayout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            Discharge2Layout = FindViewById<LinearLayout>(Resource.Id.Discharge2Layout);
            Discharge2Layout.Click += Discharge2Layout_Click;
        }

        private void Discharge2Layout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(Discharge3rdActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}