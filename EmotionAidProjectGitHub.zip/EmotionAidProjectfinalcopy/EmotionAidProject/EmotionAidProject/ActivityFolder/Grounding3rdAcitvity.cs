﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "Grounding3rdAcitvity")]
    public class Grounding3rdAcitvity : Activity
    {
        LinearLayout grounding3rdlayout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.GroundingThirdLayout);

            InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            grounding3rdlayout = FindViewById<LinearLayout>(Resource.Id.grounding3rdlayout);
            grounding3rdlayout.Click += grounding3rdlayout_Click;
        }

        private void grounding3rdlayout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(Grounding4thActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}