﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "DisChargeFirstLayout")]
    public class DisChargeFirstLayout : Activity
    {
        LinearLayout discharge1layout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.DischargeFirstLayout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {

            discharge1layout = FindViewById<LinearLayout>(Resource.Id.discharge1layout);
            discharge1layout.Click += Discharge1layout_Click;
        }

        private void Discharge1layout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(DischargeSecondActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }


    }
}