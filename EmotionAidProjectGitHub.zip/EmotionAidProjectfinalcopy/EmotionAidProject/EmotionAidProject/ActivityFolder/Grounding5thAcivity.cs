﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.ActivityFolder
{
    [Activity(Label = "Grounding5thAcivity")]
    public class Grounding5thAcivity : Activity
    {
        LinearLayout grounding5hlayout;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Grounding5thLayout);
            InitViews();
            // Create your application here
        }

        private void InitViews()
        {
            grounding5hlayout = FindViewById<LinearLayout>(Resource.Id.grounding5hlayout);
            grounding5hlayout.Click += grounding5hlayout_Click;
        }

        private void grounding5hlayout_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(GroundingLastActivity));
            StartActivity(intent);
            OverridePendingTransition(Resource.Animation.abc_tooltip_enter, Resource.Animation.abc_tooltip_exit);

        }
    }
}