﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using EmotionAidProject.Helpers;
using EmotionAidProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Firebase.Firestore;

namespace EmotionAidProject.Listeners
{
    public class ResourceEventListener : Java.Lang.Object, IEventListener
    {
        public List<ResourceBoxClass> resourcesList = new List<ResourceBoxClass>();
        public event EventHandler<ResourceEventArgs> OnResourcesRetrieved;
        
        public class ResourceEventArgs : EventArgs
        {
            public List<ResourceBoxClass> Resources {get; set;}
        }
        public ResourceEventListener()
        {
            AppDataHelper.GetFirestore().Collection(ResourceBoxClass.COLLECTION_NAME).AddSnapshotListener(this);
        }

        public void OnEvent(Java.Lang.Object value, FirebaseFirestoreException error)
        {
            var snapshot = (QuerySnapshot)value;

            this.resourcesList = new List<ResourceBoxClass>();

            foreach (DocumentSnapshot item in snapshot.Documents)
            {
                ResourceBoxClass resource = new ResourceBoxClass();
                if (item.Get("resourceName") != null)
                {
                    resource.ResourceName = item.Get("resourceName").ToString();
                }
                else
                {
                    resource.ResourceName = "";
                }
                if (item.Get("resourceId") != null)
                {
                    resource.ResourceId = item.Get("resourceId").ToString();
                }
                else
                {
                    resource.ResourceId = "";
                }
                if (item.Get("imageUrl") != null)
                {
                    resource.ImageUrl = item.Get("imageUrl").ToString();
                }
                else
                {
                    resource.ImageUrl = "";
                }
                if (item.Get("categoryName") != null)
                {
                    resource.CategoryName = item.Get("categoryName").ToString();
                }
                else
                {
                    resource.CategoryName = "";
                }
                this.resourcesList.Add(resource);
            }
            if (this.OnResourcesRetrieved != null)
            {
                OnResourcesRetrieved.Invoke(this, new ResourceEventArgs { Resources = resourcesList });
            }
        }
    }
}