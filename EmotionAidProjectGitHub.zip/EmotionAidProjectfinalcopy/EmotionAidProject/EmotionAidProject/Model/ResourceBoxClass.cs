﻿using System.Threading.Tasks;
using Firebase.Firestore;
using Java.Util;
using Android.Gms.Extensions;
using Firebase.Storage;
using EmotionAidProject.Helpers;
using EmotionAidProject.ActivityFolder;

namespace EmotionAidProject.Model
{
    public class ResourceBoxClass
    {
        public string ResourceId { get; set; }
        public string ResourceName { get; set; }
        public string CategoryName { get; set; }
        public string ResourceText { get; set; }
        public string ImageUrl { get; set; }
        protected FirebaseFirestore database;//
        public const string COLLECTION_NAME = "ResourceBox";//

        public ResourceBoxClass()
        {

        }

        public ResourceBoxClass(string ResourceName, string categoryName, string ResourceText)
        {
            this.ResourceName = ResourceName;
            this.CategoryName = categoryName;
            this.ResourceText = ResourceText;
            

            this.ResourceId = AppDataHelper.GetFirestore().Collection(COLLECTION_NAME).Document().Id;
        }

        public ResourceBoxClass(string ResourceName, string categoryName, string ImageUrl,int num)
        {
            this.ResourceName = ResourceName;
            this.CategoryName = categoryName;
            this.ImageUrl = ImageUrl;
            this.ResourceId = AppDataHelper.GetFirestore().Collection(COLLECTION_NAME).Document().Id;
        }

        public virtual async Task<bool> AddResource()
        {
            try
            {
                this.database = AppDataHelper.GetFirestore();
                DocumentReference productReference = database.Collection(COLLECTION_NAME).Document(this.ResourceId);
                HashMap recourceMap = new HashMap();
                recourceMap.Put("resourceName", this.ResourceName);
                recourceMap.Put("resourceId", this.ResourceId);
                recourceMap.Put("imageUrl", this.ImageUrl);
                recourceMap.Put("categoryName", this.CategoryName);
                recourceMap.Put("resourceText", this.ResourceText);
                await productReference.Set(recourceMap);
            }
            catch
            {
                return false;
            }
            return true;
        }
        public virtual async Task<bool>Exist()
        {
            try
            {
                this.database = AppDataHelper.GetFirestore();
                Java.Lang.Object obj = await database.Collection(COLLECTION_NAME).WhereEqualTo("resourceName", this.ResourceName).Get();
                var snapshot = (QuerySnapshot)obj;
                if (snapshot.IsEmpty)
                {
                    return false;
                }
                return true;
            }
            catch
            {
                return true;
            }
        }
        public virtual void Delete()
        {
            StorageReference storageReference = FirebaseStorage.Instance.GetReference(ResourcesBoxActivity.RESOURCE_IMAGE + this.ResourceId);
            storageReference.Delete();
            AppDataHelper.GetFirestore().Collection(COLLECTION_NAME).Document(this.ResourceId).Delete();
        }
    }
}