﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using EmotionAidProject.ActivityFolder;
using EmotionAidProject.Model;
using FFImageLoading;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject
{
    class ResourceAdapter : BaseAdapter<ResourceBoxClass>
    {

        Context context;
        List<ResourceBoxClass> resourcesList;

        public ResourceAdapter(Context context, List<ResourceBoxClass> resourcesList)
        {
            this.context = context;
            this.resourcesList = resourcesList;
        }


        public override Java.Lang.Object GetItem(int position)
        {
            return position;
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            LayoutInflater layoutInflater = ((ResourceBoxActivityShow)this.context).LayoutInflater;
            View view = layoutInflater.Inflate(Resource.Layout.layoutAddResourceRow, parent, false);
           
            ImageView addResourceIv = view.FindViewById<ImageView>(Resource.Id.addResourceIv);
            ResourceBoxClass currentResource = this.resourcesList[position];
            if (currentResource != null)
            {
               
                ImageService.Instance.LoadUrl(currentResource.ImageUrl).Retry(3, 200).DownSample(400, 400).Into(addResourceIv);
            }
            return view;
        }


        

        public override int Count
        {
            get
            {
                return this.resourcesList.Count;
            }
        }

        public override ResourceBoxClass this[int position]//מחזיר את  העצם של מיקום מסויים
        {
            get
            {
                return this.resourcesList[position];
            }
        }
    }
}

    class ResourceAdapterViewHolder : Java.Lang.Object
    {
        //Your adapter views to re-use
        //public TextView Title { get; set; }
    }
