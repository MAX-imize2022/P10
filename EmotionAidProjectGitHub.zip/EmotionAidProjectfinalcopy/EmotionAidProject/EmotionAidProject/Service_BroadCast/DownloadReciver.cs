﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using EmotionAidProject.ActivityFolder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmotionAidProject.Service_BroadCast
{
    [BroadcastReceiver(Enabled = true)]
    [IntentFilter(new[] { "radio.GAGA.Leroy.MasterYehudai" })]
    public class DownloadReciver : BroadcastReceiver
    {
        private ImageView imageView;
        private Context context;
        private ISharedPreferences sp;
        public DownloadReciver()
        { }
        public DownloadReciver(ImageView imageView, Context context)
        {
            this.imageView = imageView;
            this.context = context;
            this.sp = this.context.GetSharedPreferences("details", FileCreationMode.Private);

        }

        public override void OnReceive(Context context, Intent intent)
        {
            Toast.MakeText(context, "Received image!", ToastLength.Short).Show();
            string filePath = intent.GetStringExtra("fullPath");
            ((ResourcesBoxActivity)context).FileBytes = System.IO.File.ReadAllBytes(filePath);
            Bitmap bitmap = BitmapFactory.DecodeFile(filePath);
            this.imageView.SetImageBitmap(bitmap);

        }
    }
}